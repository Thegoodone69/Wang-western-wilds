
const balanceEl = document.getElementById('balance');
const betInput = document.getElementById('betInput');
const betBtn = document.getElementById('betBtn');
const actionBtn = document.getElementById('actionBtn');
const messageEl = document.getElementById('message');
const cockSnd = document.getElementById('cock');
const shotSnd = document.getElementById('shot');
const coinSnd = document.getElementById('coin');
const flash = document.getElementById('muzzle-flash');

let balance = 100;
let pot = 10;

function updateHUD() {
  balanceEl.textContent = balance;
}

betBtn.addEventListener('click', () => {
  pot = parseInt(betInput.value, 10);
  if (isNaN(pot) || pot <= 0 || pot > balance) {
    messageEl.textContent = "Invalid bet!";
    return;
  }
  balance -= pot;
  updateHUD();
  startDuel();
});

function startDuel() {
  messageEl.textContent = "Prepare... Don't draw too soon!";
  actionBtn.textContent = "Wait...";
  actionBtn.disabled = true;

  setTimeout(() => {
    cockSnd.play();
    actionBtn.textContent = "DRAW!";
    actionBtn.disabled = false;
    const startTime = Date.now();

    actionBtn.onclick = () => resolveDuel(startTime);
  }, 2000 + Math.random() * 2000);
}

function showFlash() {
  flash.style.display = "block";
  setTimeout(() => flash.style.display = "none", 300);
}

function resolveDuel(startTime) {
  actionBtn.disabled = true;
  const playerTime = Date.now() - startTime;
  const aiTime = Math.random() * 500 + 200;

  shotSnd.play();
  showFlash();

  if (playerTime < aiTime) {
    messageEl.textContent = `You fired in ${playerTime}ms – you WIN!`;
    balance += pot * 2;
    coinSnd.play();
  } else {
    messageEl.textContent = `You fired in ${playerTime}ms – you LOSE.`;
  }

  updateHUD();
  actionBtn.textContent = "Next Duel";
  actionBtn.disabled = false;
  actionBtn.onclick = () => {
    if (balance <= 0) {
      messageEl.textContent = "Game over! Out of coins.";
      actionBtn.disabled = true;
    } else {
      messageEl.textContent = "Place your bet to start a duel";
      actionBtn.disabled = true;
    }
  };
}

updateHUD();
