# 🤠 Wild West Duel

A fast-paced, Wild West-themed browser game where you bet coins and duel an AI opponent. Draw fast or get shot!

## 🎮 Gameplay

1. Start with 100 coins.
2. Enter your bet (any amount up to your balance).
3. Click **Bet** to initiate a duel.
4. Wait for the **DRAW!** prompt, then click **FIRE!** as fast as you can.
5. If you're faster than the AI, you win double your pot!

## 🔥 Features

- Dynamic betting system
- Click-timing based duels
- Gun cock and firing sound effects
- Muzzle flash animation
- Western-themed UI and styling

## 📁 File Structure

```
wild-west-duel/
├── index.html       # Main HTML page
├── style.css        # Styling for the game
├── game.js          # Game logic (duel, betting, RNG)
└── assets/          # Game assets
    ├── bg.jpg            # Background image
    ├── cowboy.png        # Player sprite
    ├── opponent.png      # Opponent sprite
    ├── flash.png         # Muzzle flash animation
    ├── gun_cock.mp3      # Sound: gun cock
    ├── gunshot.mp3       # Sound: gunfire
    └── coin_clink.mp3    # Sound: coin payout
```

## 🚀 How to Play

1. Download or clone the project.
2. Open `index.html` in any modern web browser (Chrome, Firefox, Edge).
3. No internet or server needed—runs completely offline!

### 🔁 Recommended: Live Server (for better asset loading)
If sound files or images don’t load in your browser:
- Use [Live Server for VS Code](https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer)
- Or host with any static file server

## 🎨 Customization

Want to make it your own? Replace the placeholder assets in `assets/`:
- `bg.jpg` → Use a saloon or desert backdrop
- `cowboy.png` / `opponent.png` → Add real character art
- `flash.png` → A quick muzzle flash or smoke puff
- Sound files → Royalty-free Western FX from freesound.org

## 📱 Mobile Support

This version is desktop-optimized. For mobile:
- Add bigger buttons
- Replace click events with `touchstart`
- Adjust CSS scaling

## 🛠️ Built With

- HTML5
- CSS3
- Vanilla JavaScript (no frameworks)

## 🏁 License

MIT — free to use and modify for any project.

---

Saddle up and may the fastest finger win!
